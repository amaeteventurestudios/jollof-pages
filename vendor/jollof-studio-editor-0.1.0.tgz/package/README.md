# @jollof/studio-editor

Jollof Studio's design editor, built from the jollofstudio repo (packages/editor-dist). See docs/EMBEDDING.md there.
